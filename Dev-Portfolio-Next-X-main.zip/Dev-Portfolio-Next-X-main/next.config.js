module.exports = {
  images: {
    domains: ["sumitdey.netlify.app"],
  },
};